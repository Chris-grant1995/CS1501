/**
 * Created by chris on 9/20/15.
 */
import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;
public class Main {

    public static void main(String[] args) throws FileNotFoundException {
        DLB myDLB = new DLB();
        File file = new File("dictionary.txt");
        Scanner scan = new Scanner(file);
        PrintWriter textFile = new PrintWriter("my_dictionary.txt");
        while (scan.hasNext()) {
            //System.out.println(scan.nextLine());
            String s = scan.nextLine();
            if (s.length() < 4) {
                //Because you can only have 3 letters in your password, we can throw out any words that have more than 3 letters, as they will never show up
                myDLB.add(s);
                textFile.println(s);
            }

        }
        textFile.close();
        //myDLB.printRoot();
         generateGoodPasswords(myDLB);
        //System.out.println(goodPasswords.toString());
        //System.out.println(myDLB.searchPrefix("eyb"));
        //System.out.println(goodPasswords.size());


    }

    public static void generateGoodPasswords(DLB dictionary) throws FileNotFoundException {
        ArrayList<String> goodPasswords = new ArrayList<String>();
        PrintWriter textFile = new PrintWriter("goodPasswords.txt");
        char[] password = new char[5];
        //goodPasswords.add("Password");
        //goodPasswords.add("Password2");
        String posChar = "bcdefghjklmnopqrstuvwxyz1234567890!@$%&*";
        //System.out.println(posChar.length());
        for (int c0 = 0; c0 < posChar.length(); c0++) {
            for (int c1 = 0; c1 < posChar.length(); c1++) {
                for (int c2 = 0; c2 < posChar.length(); c2++) {
                    for (int c3 = 0; c3 < posChar.length(); c3++) {
                        for (int c4 = 0; c4 < posChar.length(); c4++) {
                            password[0] = posChar.charAt(c0);
                            password[1] = posChar.charAt(c1);
                            password[2] = posChar.charAt(c2);
                            password[3] = posChar.charAt(c3);
                            password[4] = posChar.charAt(c4);
                            int numLetter = getNumLetters(password);
                            if (numLetter > 0 && numLetter < 4) {
                                int numNum = getNumNumbers(password);
                                if (numNum > 0 && numNum < 3) {
                                    int numSymbol = getNumSymbols(password);
                                    if (numSymbol > 0 && numSymbol < 3) {
                                        if (checkForWords(password, dictionary)) {
                                            String pw = new String(password);
                                            textFile.println(pw);
                                            //System.out.println(pw);
                                            //goodPasswords.add(pw);
                                        }

                                    }
                                }
                            }

                        }
                    }
                }
            }
        }

        textFile.close();
        //return goodPasswords;
    }

    public static int getNumLetters(char[] password) {
        String letters = "bcdefghjklmnopqrstuvwxyz";
        int counter = 0;
        for (int i = 0; i < password.length; i++) {
            if (letters.contains(Character.toString(password[i]))) {
                counter++;
            }
        }
        return counter;
    }

    public static int getNumNumbers(char[] password) {
        String letters = "1234567890";
        int counter = 0;
        for (int i = 0; i < password.length; i++) {
            if (letters.contains(Character.toString(password[i]))) {
                counter++;
            }
        }
        return counter;
    }

    public static int getNumSymbols(char[] password) {
        String letters = "!@$%&*";
        int counter = 0;
        for (int i = 0; i < password.length; i++) {
            if (letters.contains(Character.toString(password[i]))) {
                counter++;
            }
        }
        return counter;
    }

    public static boolean checkForWords(char[] password, DLB dicitionary) {
        char[] pwCopy = new String(password).toCharArray();
        char[] pwCopy2 = new String(password).toCharArray(); //Only used if there is a 1 in the password
        String replaceNum = "740315";
        boolean loop1 = false;
        boolean needPWCopy = false;
        for (int i = 0; i < password.length; i++) {
            if (password[i] == '7') {
                pwCopy[i] = 't';
                pwCopy2[i] = 't';
            } else if (password[i] == '4') {
                pwCopy[i] = 'a';
                pwCopy2[i] = 'a';
            } else if (password[i] == '0') {
                pwCopy[i] = 'o';
                pwCopy2[i] = 'o';
            } else if (password[i] == '1') {
                pwCopy[i] = 'i';
                pwCopy2[i] = 'l';
                needPWCopy = true;
            } else if (password[i] == '5') {
                pwCopy[i] = 's';
                pwCopy2[i] = 's';
            }
        }
        String letters = "abcdefghijklmnopqrstuvwxyz";
        String otherChars = "1234567890!@$%&*";
        //String pw = new String(pwCopy);
        //System.out.println(dicitionary.searchPrefix(pw));
        StringBuffer s = new StringBuffer();
        //System.out.println
        for (int i = 0; i < password.length; i++) {
            if (letters.contains(Character.toString(pwCopy[i]))) {
                s.append(pwCopy[i]);
                if(s.length()==3){
                    StringBuilder t = new StringBuilder(Character.toString(s.charAt(1)));
                    t.append(s.charAt(2));
                    int result = dicitionary.searchPrefix(t.toString());
                    if(result <2){
                        return true;
                    }
                    else if (result>1){
                        return false;
                    }

                }
                //System.out.println("Searching for " + s);
                int result = dicitionary.searchPrefix(s.toString());
                if (result == 0) {
                    if (needPWCopy) {
                        loop1 = true;
                        break;
                    } else
                        return true;

                }
                else if(result ==1){}
                else if (result > 1) {
                    return false;

                }
                else
                    s = new StringBuffer();
                }
            }
            //loop2 only should execute if there is a 1 in the password
            s = new StringBuffer();
            for (int i = 0; i < password.length; i++) {
                if (letters.contains(Character.toString(pwCopy[i]))) {
                    s.append(pwCopy2[i]);
                    //System.out.println("Searching for " + s);
                    int result = dicitionary.searchPrefix(s.toString());
                    if (result == 0) {
                        return true && loop1;
                    }
                    else if(result ==1){}
                    else if (result > 1) {
                        return false;
                    }
                    else {
                        s = new StringBuffer();
                    }
                }
                return true;
            }
        //return true;
        return false;
        }
}

